/* global React, ReactDOM, Sidebar, TopBar, Transcript, Composer, ContextRail, SESSIONS */
/* global useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle */
/* global QuestionCard */

const { useState, useEffect, useRef } = React;

const DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "accent": "amber",
  "density": "comfortable",
  "context_rail": true,
  "scenario": "waiting"
}/*EDITMODE-END*/;

const ACCENTS = [
  { key: "amber",  swatch: "oklch(0.78 0.13 70)"  },
  { key: "jade",   swatch: "oklch(0.74 0.13 155)" },
  { key: "indigo", swatch: "oklch(0.72 0.13 265)" },
  { key: "plum",   swatch: "oklch(0.70 0.13 320)" },
];

function AccentPicker({ value, onChange }) {
  return (
    <div style={{display:"flex", gap:8, padding:"4px 0"}}>
      {ACCENTS.map(a => (
        <button
          key={a.key}
          onClick={() => onChange(a.key)}
          title={a.key}
          aria-label={a.key}
          style={{
            width: 32, height: 32,
            borderRadius: 10,
            background: a.swatch,
            border: value === a.key ? "2px solid white" : "2px solid transparent",
            boxShadow: value === a.key
              ? "0 0 0 2px " + a.swatch + ", 0 6px 14px -6px rgba(0,0,0,0.5)"
              : "0 2px 6px -2px rgba(0,0,0,0.35)",
            cursor: "pointer",
            transition: "transform .12s",
            transform: value === a.key ? "scale(1.06)" : "scale(1)",
          }}
        />
      ))}
    </div>
  );
}

function App() {
  const [tweaks, setTweak] = useTweaks(DEFAULTS);
  const [activeId, setActiveId] = useState("fe55accf");
  const session = SESSIONS.find(s => s.id === activeId) || SESSIONS[0];

  useEffect(() => {
    document.documentElement.dataset.theme = tweaks.theme;
    document.documentElement.dataset.accent = tweaks.accent;
    document.documentElement.dataset.density = tweaks.density;
  }, [tweaks.theme, tweaks.accent, tweaks.density]);

  const status = tweaks.scenario;

  return (
    <div className={"app" + (tweaks.context_rail ? " with-context" : "")}>
      <Sidebar
        activeId={activeId}
        onSelect={setActiveId}
        tweaks={tweaks}
        setTweak={setTweak}
      />

      <main className="main">
        <TopBar session={session} status={status} />
        <Transcript
          status={status}
          onJumpToQuestion={() => {
            const el = document.querySelector('[data-screen-label="QuestionCard"]');
            el && el.scrollIntoView({ behavior: "smooth", block: "center" });
          }}
        />
        <div className="dock">
          {status === "waiting" && (
            <div className="question-dock">
              <QuestionCard
                onAnswer={() => setTweak("scenario", "thinking")}
              />
            </div>
          )}
          <Composer
            disabled={status === "waiting"}
            hint="Sonnet 4.5 · interactive · tools enabled"
          />
        </div>
      </main>

      {tweaks.context_rail && <ContextRail session={session} />}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio
          label="Mode"
          value={tweaks.theme}
          onChange={(v) => setTweak("theme", v)}
          options={[
            { value: "dark", label: "Dark" },
            { value: "paper", label: "Paper" },
          ]}
        />

        <TweakSection label="Accent" />
        <AccentPicker value={tweaks.accent} onChange={(v) => setTweak("accent", v)} />

        <TweakSection label="Layout" />
        <TweakRadio
          label="Density"
          value={tweaks.density}
          onChange={(v) => setTweak("density", v)}
          options={[
            { value: "comfortable", label: "Comfy" },
            { value: "compact", label: "Compact" },
          ]}
        />
        <TweakToggle
          label="Context rail"
          value={tweaks.context_rail}
          onChange={(v) => setTweak("context_rail", v)}
        />

        <TweakSection label="Scenario" />
        <TweakRadio
          label="Agent state"
          value={tweaks.scenario}
          onChange={(v) => setTweak("scenario", v)}
          options={[
            { value: "waiting",  label: "Asking" },
            { value: "thinking", label: "Working" },
          ]}
        />
      </TweaksPanel>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("app"));
root.render(<App />);
