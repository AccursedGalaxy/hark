/* global React */
const { useState, useEffect, useRef, useMemo } = React;

/* ───────────────────────────── icons ───────────────────────────── */
const I = {
  search: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>,
  plus: (p) => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" {...p}><path d="M12 5v14M5 12h14"/></svg>,
  chev: (p) => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m9 18 6-6-6-6"/></svg>,
  branch: (p) => <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="6" cy="6" r="2.5"/><circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="9" r="2.5"/><path d="M6 8.5v7"/><path d="M18 11.5c0 4-4 3-12 6.5"/></svg>,
  file: (p) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>,
  edit: (p) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 1 1 3 3L7 19l-4 1 1-4z"/></svg>,
  term: (p) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m4 7 4 5-4 5"/><path d="M12 19h8"/></svg>,
  globe: (p) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18z"/></svg>,
  send: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 19V5"/><path d="m5 12 7-7 7 7"/></svg>,
  attach: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m21 11-8.5 8.5a5 5 0 1 1-7-7L14 4a3.5 3.5 0 0 1 5 5L10.5 17.5a2 2 0 0 1-3-3L16 6"/></svg>,
  pause: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect x="6" y="5" width="3.5" height="14" rx="1"/><rect x="14.5" y="5" width="3.5" height="14" rx="1"/></svg>,
  fork: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="6" cy="5" r="2"/><circle cx="18" cy="5" r="2"/><circle cx="12" cy="20" r="2"/><path d="M6 7v3a3 3 0 0 0 3 3h6a3 3 0 0 0 3-3V7"/><path d="M12 13v5"/></svg>,
  settings: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
  share: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><path d="m16 6-4-4-4 4"/><path d="M12 2v13"/></svg>,
  question: (p) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 1-1 1.7v.5"/><circle cx="12" cy="17" r=".6" fill="currentColor"/></svg>,
  history: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/></svg>,
  spark: (p) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/></svg>,
};

/* ───────────────────────────── data ───────────────────────────── */
const SESSIONS = [
  {
    id: "fe55accf", name: "hark", project: "~/Projects/hark",
    branch: "feat/task-state", status: "waiting", agent: "interactive",
    devTag: "dev:2.1", summary: "Add a TaskState panel that tracks live task graphs from the LSP.",
    when: "now",
  },
  {
    id: "a17b3c92", name: "hark", project: "~/Projects/hark",
    branch: "main", status: "live", agent: "interactive",
    devTag: "dev:1.1", summary: "Investigating the WebSocket reconnect storm during long-running tool calls.",
    when: "2m",
  },
  {
    id: "9d8e1102", name: "hark", project: "~/Projects/hark",
    branch: "fix/diff-pane", status: "idle", agent: "interactive",
    devTag: "dev:1.2", summary: "Final pass on the inline diff renderer — wrapping behavior on narrow viewports.",
    when: "1h",
  },
  {
    id: "0b22e771", name: "marshmellow", project: "~/Projects/marshmellow",
    branch: "rfc/auth", status: "idle", agent: "agentic",
    devTag: "dev:3.0", summary: "Sketch the magic-link sign-in flow + rotate token endpoint.",
    when: "yesterday",
  },
  {
    id: "7c014ee9", name: "kettle", project: "~/Code/kettle",
    branch: "main", status: "error", agent: "interactive",
    devTag: "dev:0.4", summary: "Build crashed in CI — sqlx prepared statements are stale after the schema change.",
    when: "yesterday",
  },
];

/* ───────────────────────────── sidebar ────────────────────────── */
function Sidebar({ activeId, onSelect, tweaks, setTweak }) {
  const grouped = useMemo(() => {
    return {
      active: SESSIONS.filter(s => s.status === "live" || s.status === "waiting"),
      idle:   SESSIONS.filter(s => s.status === "idle"),
      attn:   SESSIONS.filter(s => s.status === "error"),
    };
  }, []);

  return (
    <aside className="rail" data-screen-label="Sidebar">
      <div className="rail-head">
        <div className="brand">
          <span className="brand-dot"></span>
          hark
        </div>
        <div className="brand-meta">
          <div className="theme-switch" role="tablist" aria-label="Theme">
            <button className={tweaks.theme === "dark" ? "on" : ""} onClick={() => setTweak("theme", "dark")}>Dark</button>
            <button className={tweaks.theme === "paper" ? "on" : ""} onClick={() => setTweak("theme", "paper")}>Paper</button>
          </div>
        </div>
      </div>

      <div className="rail-search">
        <span className="icn"><I.search /></span>
        <input placeholder="Search sessions, files, commands…" />
        <kbd>⌘K</kbd>
      </div>

      <button className="new-btn">
        <span className="plus"><I.plus /></span>
        <span>New session</span>
        <span style={{marginLeft:"auto", fontFamily:"var(--mono)", fontSize:11, color:"var(--fg-3)"}}>⌘N</span>
      </button>

      <div className="section-label">
        <span>Needs you</span>
        <span className="count">{grouped.active.length + grouped.attn.length}</span>
      </div>
      <div className="sessions">
        {[...grouped.active, ...grouped.attn, ...grouped.idle].map(s => (
          <SessionRow
            key={s.id}
            session={s}
            active={s.id === activeId}
            onClick={() => onSelect(s.id)}
          />
        ))}
      </div>

      <div className="rail-footer">
        <div className="avatar">a</div>
        <div>
          <div className="who">aki</div>
          <div className="role">workspace · personal</div>
        </div>
        <button className="icon-btn" style={{marginLeft:"auto"}} title="Settings"><I.settings /></button>
      </div>
    </aside>
  );
}

function SessionRow({ session, active, onClick }) {
  const statusLabel = {
    live: "LIVE", idle: "IDLE", waiting: "ASKING", error: "FAILED",
  }[session.status];
  return (
    <div className={"session" + (active ? " active" : "")} onClick={onClick}>
      <div className="session-top">
        <span className="session-name">{session.name}</span>
        <span className="session-status">
          <span className={"dot " + session.status}></span>
          {statusLabel}
        </span>
      </div>
      <div className="session-meta">
        <span className={"tag " + (active ? "accent" : "")}>{session.agent}</span>
        <span className="tag">{session.devTag}</span>
        <span style={{marginLeft:"auto", color:"var(--fg-3)"}}>{session.when}</span>
      </div>
      <div className="session-path">
        <span>{session.project}</span>
        <span>·</span>
        <span className="branch"><I.branch /> {session.branch}</span>
      </div>
      {active && (
        <div className="session-summary">{session.summary}</div>
      )}
    </div>
  );
}

/* ───────────────────────────── topbar ─────────────────────────── */
function TopBar({ session, status }) {
  return (
    <header className="topbar" data-screen-label="TopBar">
      <div className="crumbs">
        <span>{session.project.replace(/^~\//,"~/")}</span>
        <span className="sep">/</span>
        <span className="here">{session.name}</span>
        <span className="branch" style={{marginLeft:8}}>
          <I.branch /> {session.branch}
        </span>
      </div>

      {status === "waiting" ? (
        <div className="status-chip waiting">
          <span className="pulse"></span> Awaiting your input
        </div>
      ) : (
        <div className="status-chip">
          <span className="pulse"></span> Thinking · 14s
        </div>
      )}

      <div className="spacer"></div>

      <div className="topbar-meta">
        <span className="id">#{session.id}</span>
        <span style={{opacity:.5}}>·</span>
        <span>14 turns</span>
        <span style={{opacity:.5}}>·</span>
        <span>Sonnet 4.5</span>
      </div>

      <div style={{display:"flex", gap:4}}>
        <button className="icon-btn" title="History"><I.history /></button>
        <button className="icon-btn" title="Fork session"><I.fork /></button>
        <button className="icon-btn" title="Share"><I.share /></button>
        <button className="icon-btn danger" title="Pause agent"><I.pause /></button>
      </div>
    </header>
  );
}

/* ───────────────────────────── tool capsule ───────────────────── */
function Tool({ kind, name, path, pills, status, summary, body, defaultOpen=false }) {
  const [open, setOpen] = useState(defaultOpen);
  const glyph = { read: <I.file/>, write: <I.edit/>, shell: <I.term/>, web: <I.globe/> }[kind];
  return (
    <div className={"tool " + kind + (status ? " " + status : "") + (open ? " open" : "")}>
      <button className="tool-head" onClick={() => setOpen(o => !o)}>
        <span className="led"></span>
        <span className="glyph">{glyph}</span>
        <span className="tool-title">
          <span className="name">{name}</span>
          {path && <span className="path">{path}</span>}
        </span>
        <span className="tool-meta">
          {(pills || []).map((p, i) => (
            <span key={i} className={"diff-pill " + p.kind}>{p.label}</span>
          ))}
        </span>
        <span className="chev"><I.chev /></span>
      </button>
      {open && (
        <div className="tool-body">
          {summary && <div className="summary">{summary}</div>}
          {body}
        </div>
      )}
    </div>
  );
}

/* ───────────────────────────── question card ──────────────────── */
const QUESTION = {
  prompt: "How should I reconcile the diverged TaskState across sessions?",
  detail: "Both dev:2.1 and dev:1.1 wrote to the same task graph in the last 30s. I can resolve this in a few ways — your call.",
  options: [
    {
      id: "merge",
      title: "Merge both branches into a unified graph",
      desc: "Apply dev:1.1's edits over dev:2.1, preserving newer timestamps. Safe, but loses dev:2.1's manual reorders.",
      meta: "~12s · reversible",
      recommended: true,
    },
    {
      id: "keep-active",
      title: "Keep this session's state, discard the other",
      desc: "Overwrites dev:1.1 with the graph as it stands in dev:2.1. Fast, but the other session will rebase on next focus.",
      meta: "~3s",
    },
    {
      id: "side-by-side",
      title: "Fork the graph and present them side-by-side",
      desc: "Opens a diff view so you can hand-pick nodes. Recommended when the graphs share more than 60% overlap.",
      meta: "~8s · opens diff",
    },
    {
      id: "abort",
      title: "Pause and let me investigate manually",
      desc: "I'll suspend the run and surface both states in the context rail. You drive from here.",
      meta: "manual",
    },
  ],
};

function QuestionCard({ onAnswer }) {
  const [picked, setPicked] = useState("merge");
  const [sent, setSent] = useState(false);

  useEffect(() => {
    const onKey = (e) => {
      if (sent) return;
      const idx = "1234".indexOf(e.key);
      if (idx >= 0 && QUESTION.options[idx]) {
        setPicked(QUESTION.options[idx].id);
        e.preventDefault();
      } else if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
        submit();
        e.preventDefault();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [picked, sent]);

  const submit = () => {
    if (sent) return;
    setSent(true);
    onAnswer && onAnswer(picked);
  };

  return (
    <div className="question" data-screen-label="QuestionCard">
      <span className="q-tag">
        <span className="pulse"></span>
        Claude is asking
      </span>
      <div className="q-title">{QUESTION.prompt}</div>
      <div className="q-sub">{QUESTION.detail}</div>

      <div className="q-options" role="radiogroup">
        {QUESTION.options.map((opt, i) => (
          <button
            key={opt.id}
            role="radio"
            aria-checked={picked === opt.id}
            className={"q-opt" + (picked === opt.id ? " selected" : "") + (opt.recommended ? " rec" : "")}
            onClick={() => setPicked(opt.id)}
            onDoubleClick={submit}
          >
            <span className="key">{i + 1}</span>
            <span>
              <span className="head">{opt.title}</span>
              <span className="body">{opt.desc}</span>
            </span>
            <span className="meta">{opt.meta}</span>
          </button>
        ))}
      </div>

      <div className="q-actions">
        <span className="hint"><kbd>1</kbd>–<kbd>4</kbd> to pick</span>
        <span className="hint"><kbd>⌘</kbd><kbd>↵</kbd> to send</span>
        <button className="btn-custom">Or write a custom reply…</button>
        <span className="spc"></span>
        <button className="btn primary" onClick={submit} disabled={sent}>
          {sent ? "Sent" : "Send answer"}
          <I.send />
        </button>
      </div>
    </div>
  );
}

/* ───────────────────────────── composer ───────────────────────── */
function Composer({ disabled, hint }) {
  const [val, setVal] = useState("");
  const ref = useRef(null);
  useEffect(() => {
    const t = ref.current;
    if (!t) return;
    t.style.height = "auto";
    t.style.height = Math.min(t.scrollHeight, 240) + "px";
  }, [val]);
  return (
    <div className="composer-wrap">
      <div className="composer">
        <div className="composer-top">
          <button className="chip"><I.attach /> Attach</button>
          <button className="chip"><I.spark /> @file</button>
          <button className="chip"><I.term /> /run</button>
          <button className="chip warn" title="Plan mode"><I.question /> Plan mode</button>
          <span style={{flex:1}}></span>
          <span className="chip" style={{cursor:"default"}}>
            <span className="dot live" style={{width:6,height:6}}></span> connected
          </span>
        </div>
        <div className="composer-input">
          <textarea
            ref={ref}
            disabled={disabled}
            placeholder={disabled ? "Answer the question above to continue…" : "Reply, or describe what to do next…"}
            value={val}
            onChange={(e) => setVal(e.target.value)}
            rows={1}
          />
          <button className="send" disabled={disabled || !val.trim()} aria-label="Send">
            <I.send />
          </button>
        </div>
        <div className="composer-foot">
          <span>{hint || "Sonnet 4.5 · interactive · tools enabled"}</span>
          <span className="spc"></span>
          <span><kbd>↵</kbd> send · <kbd>⇧</kbd><kbd>↵</kbd> newline · <kbd>⌘</kbd><kbd>/</kbd> commands</span>
        </div>
      </div>
    </div>
  );
}

/* ───────────────────────────── transcript ─────────────────────── */
function Transcript({ status, onJumpToQuestion }) {
  return (
    <div className="transcript" data-screen-label="Transcript">
      <div className="thread">
        <div className="turn user">
          <span className="who">aki · 12:04</span>
          <div className="bubble">
            Sessions are silently overwriting each other's task graphs when both are interactive. Can you instrument it and propose a fix?
          </div>
        </div>

        <div className="assistant-marker">
          <span className="av"></span> claude · sonnet 4.5
        </div>

        <div className="assistant-line">
          I'll start by reading the current <code>TaskState</code> module and the LSP bridge that publishes it. Then I'll add the instrumentation hooks before proposing the merge strategy.
        </div>

        <div className="tool-group">
          <div className="tool-group-head">
            <span className="acc">●</span> read · 3 files · context
            <span style={{marginLeft:"auto", color:"var(--fg-3)"}}>2.1s</span>
          </div>
          <Tool
            kind="read" name="taskState.ts" path="~/Projects/hark/web/src/lib/taskState.ts"
            pills={[{kind:"lines", label:"218 lines"}]}
          />
          <Tool
            kind="read" name="lspBridge.ts" path="~/Projects/hark/web/src/lib/lspBridge.ts"
            pills={[{kind:"lines", label:"94 lines"}]}
          />
          <Tool
            kind="read" name="App.tsx" path="~/Projects/hark/web/src/App.tsx"
            pills={[{kind:"lines", label:"204 lines"}]}
          />
        </div>

        <div className="assistant-line">
          Confirmed — both writers funnel through <code>publishGraph()</code> without a CRDT or write lock. I'll add a write-fence and an instrumentation tap so we can see the collisions. Running the suite first to baseline.
        </div>

        <Tool
          kind="shell"
          name="$ npx vitest run --reporter=basic 2>&1 | tail -40"
          pills={[{kind:"new", label:"270 pass"}]}
          summary="All 270 tests pass including the new 13 taskState tests."
          body={<pre>
{`Test Files  18 passed (18)
     Tests  270 passed (270)
  Start at  12:04:23
  Duration  6.43s (transform 412ms, setup 0ms, collect 1.2s)
`}
          </pre>}
        />

        <div className="assistant-line">
          Now wiring the instrumentation. The diff below adds a <code>writeFence</code> guard around any external mutation and surfaces the conflict at the call site.
        </div>

        <Tool
          kind="write" name="taskState.ts" path="~/Projects/hark/web/src/lib/taskState.ts"
          pills={[{kind:"add", label:"+57"}, {kind:"del", label:"−2"}]}
          defaultOpen
          summary="Adds writeFence(), conflict surface, and a debug tap on publishGraph()."
          body={<pre>
            <span className="diff-line ctx">{`   export function publishGraph(next: TaskGraph) {`}</span>{"\n"}
            <span className="diff-line del">{`-    state.graph = next`}</span>{"\n"}
            <span className="diff-line del">{`-    emit("graph", next)`}</span>{"\n"}
            <span className="diff-line add">{`+    const fence = writeFence(next, state.graph)`}</span>{"\n"}
            <span className="diff-line add">{`+    if (fence.conflict) {`}</span>{"\n"}
            <span className="diff-line add">{`+      emit("conflict", fence)`}</span>{"\n"}
            <span className="diff-line add">{`+      return askUser(fence)   // prompts via the host`}</span>{"\n"}
            <span className="diff-line add">{`+    }`}</span>{"\n"}
            <span className="diff-line add">{`+    state.graph = fence.merged ?? next`}</span>{"\n"}
            <span className="diff-line ctx">{`     emit("graph", state.graph)`}</span>{"\n"}
            <span className="diff-line ctx">{`   }`}</span>
          </pre>}
        />

        <Tool
          kind="write" name="toolFormat.ts" path="~/Projects/hark/web/src/lib/toolFormat.ts"
          pills={[{kind:"add", label:"+29"}]}
          summary="Surface conflict + fence events in the transcript renderer."
        />

        <div className="assistant-line">
          I detected an actual conflict between this session (<code>dev:2.1</code>) and <code>dev:1.1</code> just now while writing the fence. Before I continue, I need a call from you on how to reconcile it.
        </div>

        {status === "waiting" && (
          <button className="q-pointer" onClick={onJumpToQuestion}>
            <span className="led"></span>
            <span>
              <span className="lbl" style={{display:"block", marginBottom:2}}>Claude is asking</span>
              <span className="txt">How should I reconcile the diverged TaskState across sessions?</span>
            </span>
            <span className="jump">Jump to question <I.chev /></span>
          </button>
        )}
      </div>
    </div>
  );
}

/* ───────────────────────────── context rail ───────────────────── */
function ContextRail({ session }) {
  return (
    <aside className="context-rail" data-screen-label="ContextRail">
      <div className="ctx-section">
        <h4>Session</h4>
        <dl className="kv">
          <dt>id</dt><dd>#{session.id}</dd>
          <dt>started</dt><dd>12 min ago</dd>
          <dt>model</dt><dd>Sonnet 4.5</dd>
          <dt>mode</dt><dd>interactive</dd>
          <dt>cwd</dt><dd style={{fontFamily:"var(--mono)", fontSize:12}}>{session.project}</dd>
          <dt>branch</dt><dd style={{fontFamily:"var(--mono)", fontSize:12, color:"var(--indigo)"}}>{session.branch}</dd>
        </dl>
      </div>

      <div className="ctx-section">
        <h4>Context window</h4>
        <div className="metric">
          <span className="num">42<span style={{fontSize:18, color:"var(--fg-3)"}}>%</span></span>
          <span className="lbl">82.4k / 200k</span>
        </div>
        <div className="bar"><i style={{width:"42%"}}></i></div>
      </div>

      <div className="ctx-section">
        <h4>Recent files</h4>
        <div className="ctx-file"><I.edit /> taskState.ts <span className="dl">+57</span></div>
        <div className="ctx-file"><I.edit /> toolFormat.ts <span className="dl">+29</span></div>
        <div className="ctx-file"><I.file /> App.tsx <span className="dl">204L</span></div>
        <div className="ctx-file"><I.file /> lspBridge.ts <span className="dl">94L</span></div>
      </div>

      <div className="ctx-section">
        <h4>Permissions</h4>
        <dl className="kv">
          <dt>shell</dt><dd style={{color:"var(--jade)"}}>allowed</dd>
          <dt>net</dt><dd style={{color:"var(--amber)"}}>ask</dd>
          <dt>write</dt><dd style={{color:"var(--jade)"}}>{session.project}/**</dd>
        </dl>
      </div>
    </aside>
  );
}

Object.assign(window, {
  Sidebar, TopBar, Transcript, Composer, ContextRail, QuestionCard, SESSIONS,
});